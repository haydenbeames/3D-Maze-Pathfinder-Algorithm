#ifndef PATHFINDER_H
#define PATHFINDER_H

#include "PathfinderInterface.h"
#include <vector>
#include <string>

class Pathfinder : public PathfinderInterface {
protected:
	static const int ROW_SIZE = 5;
	static const int COL_SIZE = 5;
	static const int HEIGHT_SIZE = 5;
	const int BACKGROUND = 1;
	const int WALL = 0;
	const int TEMPORARY = 2;
	const int PATH = 3;
	int maze_grid[ROW_SIZE][COL_SIZE][HEIGHT_SIZE];
	vector<string> solution;

	public:
	  Pathfinder();
		~Pathfinder() {};
		bool importMaze(string file_name);
		string toString() const;
		vector<string> solveMaze();
		int cube_copy[ROW_SIZE][COL_SIZE][HEIGHT_SIZE];
		void createRandomMaze();
		bool find_maze_path(int cube[ROW_SIZE][COL_SIZE][HEIGHT_SIZE], int r, int c, int h);
};

#endif
#include "Pathfinder.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <stdio.h>      
#include <stdlib.h>     
#include <time.h>
#include <stack>

using namespace std;

Pathfinder::Pathfinder() {
	srand(time(NULL));
	for(int height = 0; height < HEIGHT_SIZE; height++) {
	        for(int row = 0; row < ROW_SIZE; row++) {
							for(int col = 0; col < COL_SIZE; col++) {
								maze_grid[col][row][height] = 1;
							}
					}
	}

}

string Pathfinder::toString() const {
	    stringstream ss;
	    for(int height = 0; height < HEIGHT_SIZE; height++) {
	        for(int row = 0; row < ROW_SIZE; row++) {
							for(int col = 0; col < COL_SIZE; col++) {
									ss << maze_grid[row][col][height];
									if (col < 4) {
										ss << " ";
									}
	        		}
	        		ss << endl;
					}
					
					if (height < 4) {
						ss << endl;
					}
	    }
	    return ss.str();
}


bool Pathfinder::importMaze(string file_name) {
	cout << "importMaze from "<<file_name<<endl;
	string each_line; 
	ifstream file (file_name);
	
	string mazeString;
	if (file.is_open() == false) {
		return false;
	}
	while (getline(file, each_line)) {
		istringstream iss(each_line);
		string rawLine;
		
		while (iss >> rawLine) {
				string digitLine = "";
				for(auto &d : rawLine) { // remove spaces digitcheck      
						if (isdigit(d) && ((d == '1') || d == '0')) {
								//digitLine +=d;   
								
								mazeString +=d;   
							}
						else {
							return false;
							}
						}
				}
				
		}
		
		
		int mazeDigit = 0;
		if (mazeString.size() != 125 || mazeString.at(0) != '1' || mazeString.at(mazeString.size() - 1) != '1') {
			return false;
		}
		cout << mazeString << endl;
		
		for(int height = 0; height < HEIGHT_SIZE; height++) {
				for(int row = 0; row < ROW_SIZE; row++) {
					for(int col = 0; col < COL_SIZE; col++) {
					
						if (mazeString.front() == '0') {
							mazeDigit = WALL;
						}
						else if (mazeString.front() == '1') {
							mazeDigit = BACKGROUND;
						}
						else {
							return false;
						}
					
			
						maze_grid[row][col][height] = mazeDigit;
						
						int position = 0;
						mazeString.erase(position, 1);
						cout << "["<<row<<"]["<<col<<"]["<<height<<"]=" << maze_grid[row][col][height] << endl;
							}
						}
					}
		return(true);
	}

		

vector<string> Pathfinder::solveMaze() {
	for(int height = 0; height < HEIGHT_SIZE; height++) {
	        for(int row = 0; row < ROW_SIZE; row++) {
							for(int col = 0; col < COL_SIZE; col++) {
								cube_copy[row][col][height] = maze_grid[row][col][height];
			}
		}
	}
	find_maze_path(cube_copy,0,0,0);
	stack <string> reorder;
	vector <string> reordervect;
	reordervect.resize(solution.size());


	for (int i = 0; i < solution.size(); i++) {
		reordervect.at(i)=(solution.at(solution.size() - 1 - i));
	}
	solution.clear();
	
	for(auto s:reordervect) {
		cout << s << endl;

	}
	return reordervect;
}


void Pathfinder::createRandomMaze() {
	for(int height = 0; height < HEIGHT_SIZE; height++) {
	        for(int row = 0; row < ROW_SIZE; row++) {
							for(int col = 0; col < COL_SIZE; col++) {
				maze_grid[row][col][height] = rand() % 2;
			}
		}
	}
	maze_grid[0][0][0] = 1;
	maze_grid[4][4][4] = 1;
}

bool Pathfinder::find_maze_path(int cube_copy[ROW_SIZE][COL_SIZE][HEIGHT_SIZE], int r, int c, int h) {
	
		//solution.push_back("(r,c,h)");
	  //cout << "find_maze_path ["<<r<<"]["<<c<<"]["<<h<<"]"<<endl;
	  //cout << this->toString();
	  if (r < 0 || c < 0 || h < 0 || r >= ROW_SIZE || c >= COL_SIZE || h >= HEIGHT_SIZE)
	    return false;      // Cell is out of bounds.
	  else if (cube_copy[r][c][h] != BACKGROUND)
	    return false;      // Cell is on barrier or dead end.
	  else if (r == ROW_SIZE - 1 && c == COL_SIZE - 1 && h == HEIGHT_SIZE - 1) {
	    cube_copy[r][c][h] = PATH;         // Cell is on path
	    solution.push_back("("+to_string(c)+", "+to_string(r)+", "+to_string(h)+")");
	    return true;               // and is maze exit.
	  }
	  else { 
	    // Recursive case.
	    // Attempt to find a path from each neighbor.
	    // Tentatively mark cell as on path.
	    cube_copy[r][c][h] = PATH;
	    if (find_maze_path(cube_copy, r - 1, c, h) // Up
	        || find_maze_path(cube_copy, r + 1, c, h) // Down
	        || find_maze_path(cube_copy, r, c - 1, h) // Left
	        || find_maze_path(cube_copy, r, c + 1, h) 
					|| find_maze_path(cube_copy, r, c, h - 1) 
	        || find_maze_path(cube_copy, r, c, h + 1) ) { // Right
	      solution.push_back("("+to_string(c)+", "+to_string(r)+", "+to_string(h)+")");
	      return true;
	    }
	    else {
	      cube_copy[r][c][h] = TEMPORARY;  // Dead end.
	      return false;
	    }
	  }
	}


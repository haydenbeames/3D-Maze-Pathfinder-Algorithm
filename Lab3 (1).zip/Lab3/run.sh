make 
./maze
bash check.sh